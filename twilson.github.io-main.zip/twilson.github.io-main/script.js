// script.js
// Tara Wilson - script.js

document.getElementById('alertButton').addEventListener('click', function() {
    alert('Button clicked!');
});
